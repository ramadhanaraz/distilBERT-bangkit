from setuptools import setup

setup(
    name='dBERT_custom_code',
    version='1.0',
    scripts=['predictor.py', 'preprocess.py'])
