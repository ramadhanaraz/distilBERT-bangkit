# distilBERT-bangkit
A distilled version of BERT transformer for text classification tasks

Saved model and checkpoint path for this model is available at : https://drive.google.com/drive/u/0/folders/1_05Ks2Dshgy0jdMRVM1sHxzH_aLOvNbB
